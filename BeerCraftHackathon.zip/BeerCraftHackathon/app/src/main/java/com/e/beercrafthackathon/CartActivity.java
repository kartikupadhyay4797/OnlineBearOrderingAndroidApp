package com.e.beercrafthackathon;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mealgaadi.Session;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class CartActivity extends AppCompatActivity {
    Intent intent1;
    public static RecyclerView recyclerViewItem;
    public static double tax_percentage;
    public static TextView subtotalView,total_amt,taxView;
    LinearLayout paymentMode;
    static RadioGroup paymentSelection;
    static RadioButton selectedPaymentMethod;
    RelativeLayout checkout;
    static CartAdapter adapterItem;
    public static ArrayList<Item> list;
    static Activity Cart;
    Button pressToPlaceOrder;
    static double total;
    ScrollView scroll;
    static ProgressBar progress;
    static String checksum;
    static View view;
    static String orderId;
    static final int PAYTMTRANSACTIONREQUESTCODE=1;
    static String orderObjString;
    static JsonObject orderObj;
    static DatabaseCreation dbc;
    static SQLiteDatabase dbw,dbr;
    static ContentValues cv;
    static Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_cart);
        progress=findViewById(R.id.progress_in_cart);
        Cart=CartActivity.this;
        paymentMode=findViewById(R.id.payment_method);
        paymentSelection=findViewById(R.id.payment_selection);
        scroll=findViewById(R.id.scroll_in_cart_activity);

        list=new ArrayList<>();
        dbc=new DatabaseCreation(getApplicationContext());
        dbw=dbc.getWritableDatabase();
        dbr=dbc.getReadableDatabase();
        cv=new ContentValues();

        try {
            cursor = dbr.rawQuery("select * from " + FeedReader.FeedEntry.TABLE_NAME, null);

            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {
                    Item item=new Item();
                    item.setName(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.ITEM_NAME)));
                    item.setMenu_Id(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.ITEM_ID)));
                    item.setPriceForCart(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.ITEM_PRICE)));
                    item.setQuantity(Integer.parseInt(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.ITEM_QTY))));
                    item.setType(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.ITEM_TYPE)));
                    list.add(item);
                    cursor.moveToNext();
                }
            }
        }catch (SQLiteException e){}

        if(list==null)
            list=new ArrayList<Item>();

        orderId=String.valueOf(Math.abs(new Random().nextLong()));
        tax_percentage=0;
        int subtotal=0;
        if(list!=null)
        subtotal=getSubtotal(subtotal,list);
        if(subtotal<0)
            subtotal=0;
        subtotalView=(TextView)findViewById(R.id.subtotal);
        subtotalView.setText("₹ "+(double)subtotal);
        taxView =(TextView)findViewById(R.id.tax_final_amount);
        double tax=subtotal*tax_percentage/100;
        if(tax<=0)
            tax=0.00;
        taxView.setText("₹ "+tax);
        total_amt=(TextView)findViewById(R.id.total_amt);
        total=subtotal+tax;

        total_amt.setText("₹ "+total);

        recyclerViewItem=(RecyclerView)findViewById(R.id.items_in_cart);
        if (list!=null && list.size()!=0)
            findViewById(R.id.item_card_view_in_cart).setVisibility(View.VISIBLE);

        LinearLayoutManager linearLayoutManagerCartItems = new LinearLayoutManager(this);
        recyclerViewItem.setLayoutManager(linearLayoutManagerCartItems);
        recyclerViewItem.setHasFixedSize(true);

        adapterItem = new CartAdapter(list);
        recyclerViewItem.setAdapter(adapterItem);

        Button continueShopping=(Button)findViewById(R.id.continue_shopping);
        continueShopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CartActivity.this,MainActivity.class);
                intent.putExtra("backFromCart",true);
                startActivity(intent);
                CartActivity.this.finish();
            }
        });
        pressToPlaceOrder=findViewById(R.id.place_order);

        checkout=(RelativeLayout) findViewById(R.id.checkout);
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(list.size()>0) {

                    if(new Session(CartActivity.this).getAddress()==null || new Session(CartActivity.this).getAddress().isEmpty()){
                        new Toast(CartActivity.this).makeText(CartActivity.this,"Please set your address & city here.",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(CartActivity.this, UserProfile.class));
                        CartActivity.this.finish();
                    }
                    else if(!new Session(CartActivity.this).getCity().trim().equalsIgnoreCase("indore")){
                        new Toast(CartActivity.this).makeText(CartActivity.this,"We're so sorry, we do not serve in this area, please try again after changing your address.",Toast.LENGTH_LONG).show();
                    }
                    else {
                        paymentMode.setVisibility(View.VISIBLE);
                        checkout.setVisibility(View.GONE);
                        pressToPlaceOrder.setVisibility(View.VISIBLE);
//                    scroll.fullScroll(View.FOCUS_DOWN);
                        scroll.post(new Runnable() {
                            @Override
                            public void run() {
                                scroll.fullScroll(View.FOCUS_DOWN);
                            }
                        });
                    }
                }
                else {
                        new AlertDialog.Builder(CartActivity.this)
                                .setTitle("Oops!!!")
                                .setMessage("Your cart is empty, add at least one item to your cart first.")

                                // Specifying a listener allows you to take an action before dismissing the dialog.
                                // The dialog is automatically dismissed when a dialog button is clicked.
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        // Continue with delete operation
                                    }
                                })

                                // A null listener allows the button to dismiss the dialog and take no further action.
                                .setIcon(R.drawable.nav_header_image)
                                .show();
                }
            }
        });

        paymentSelection.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                selectedPaymentMethod=group.findViewById(checkedId);
                if (selectedPaymentMethod.getText().toString().equals("Cash")){
                    pressToPlaceOrder.setText("Place Order");
                }
                else {
                    pressToPlaceOrder.setText("Pay Now");
                }
//                new CallChecksum(CartActivity.this).execute();
            }
        });


        Session session=new Session(this);
        JsonObject tempuser=new JsonObject(),tempitem;
        JsonArray temparrayitem=new JsonArray(),temparrayuser=new JsonArray();
        orderObj=new JsonObject();
        for(int i=0;i<CartActivity.list.size();i++){
            tempitem=new JsonObject();
            tempitem.addProperty("name",CartActivity.list.get(i).getName());
            tempitem.addProperty("id",CartActivity.list.get(i).getMenu_Id());
            tempitem.addProperty("quantity",CartActivity.list.get(i).getQuantity());
            tempitem.addProperty("type",CartActivity.list.get(i).getType());
            tempitem.addProperty("price",CartActivity.list.get(i).getPriceForCart().substring(2));
            temparrayitem.add(tempitem);
            tempitem=null;
        }
        tempuser.addProperty("name",session.getUserName());
        tempuser.addProperty("number",session.getUserNumber());
        tempuser.addProperty("id",session.getUserId());
        tempuser.addProperty("latitude",String.valueOf(session.getLatitude()));
        tempuser.addProperty("longitude",String.valueOf(session.getLongitude()));
        tempuser.addProperty("address1",session.getAddress());
        tempuser.addProperty("address2",session.getAddress());
        temparrayuser.add(tempuser);
        orderObj.add("cart",temparrayitem);
        orderObj.add("customer",temparrayuser);
        orderObj.addProperty("method","createOrder");
        Log.e("cartaddress",temparrayuser.toString());

    }



    public static int getSubtotal(int subtotal,ArrayList<Item> list){
        for (int i=0;i<list.size();i++)
            subtotal+=(Integer.parseInt(list.get(i).getPriceForCart().substring(2))*list.get(i).getQuantity());
        return subtotal;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case android.R.id.home:
                Intent intent=new Intent(CartActivity.this,MainActivity.class);
                intent.putExtra("backFromCart",true);
                startActivity(intent);
                CartActivity.this.finish();
        }
        return true;
    }

    public void orderPlaced(View view){

        new AlertDialog.Builder(CartActivity.this)
                .setTitle("Are You Sure?")
                .setMessage("Do you want us to deliever at :\nAddress: "+new Session(CartActivity.this).getAddress()+"\nCity: "+new Session(CartActivity.this).getCity())

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                        CartActivity.view=view;
//        new CallChecksum(CartActivity.this).execute();
                        orderPlacing();
                        // Continue with delete operation
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        new Toast(CartActivity.this).makeText(CartActivity.this,"Please change your address here.",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(CartActivity.this, UserProfile.class));
                        CartActivity.this.finish();
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setIcon(R.drawable.nav_header_image)
                .show();
    }
    //"https://www.mealgaadi.in//paytm_App/generateChecksum_new.php"
    //----------
    //{"MERCHANT_KEY":"g8x#%F286@KtBG5A","MID":"iKzvBt45457756179911","ORDER_ID":"4745857575934457115","CHANNEL_ID":"WAP","CUST_ID":"11050","MOBILE_NO":"9981898550","EMAIL":"kartik4797@gmail.com","TXN_AMOUNT":"70.7","WEBSITE":"WEBSTAGGING","INDUSTRY_TYPE_ID":"Retail","CALLBACK_URL":"https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=4745857575934457115"}
    //----------
    //"https://www.mealgaadi.in//paytm_App/verifyChecksum.php"
    //----------
    //{"MERCHANT_KEY":"g8x#%F286@KtBG5A","MID":"iKzvBt45457756179911","ORDER_ID":"4745857575934457115","CHANNEL_ID":"WAP","CUST_ID":"11050","MOBILE_NO":"9981898550","EMAIL":"kartik4797@gmail.com","TXN_AMOUNT":"70.7","WEBSITE":"WEBSTAGGING","INDUSTRY_TYPE_ID":"Retail","CALLBACK_URL":"https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=4745857575934457115","CHECKSUMHASH":""}

    static void orderPlacing() {
        //new CallCartData(this).execute();

        selectedPaymentMethod=CartActivity.Cart.findViewById(paymentSelection.getCheckedRadioButtonId());
        orderObj.addProperty("pay_via",selectedPaymentMethod.getText().toString());
        if (selectedPaymentMethod.getText().toString().equals("Cash")) {
            OkHttpClient client=new OkHttpClient();
            RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), orderObj.toString());
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url("https://www.mealgaadi.in/user_administrator_api/orderCreation.php")
                    .post(body)
                    .build();
//                try {
            Log.e("place order req: ",request.toString());
            client.newCall(request).enqueue(new okhttp3.Callback() {
                @Override
                public void onFailure(okhttp3.Call call, IOException e) {
                    Log.e("on failure : ", call.toString() + "exception " + e.getMessage());
                    final String message = e.getMessage();
                }

                @Override
                public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                    final String checksum = response.body().string();
                    Log.e("this is object: ", checksum);
//                    JsonObject json=new JsonObject();
//                    json= (JsonObject) new JsonParser().parse(checksum);
//                    if(json.get("status").equals("200")){
//                        String msg=json.getAsJsonArray("result").get(0).getAsJsonObject().get("msg").toString();
//                        new Toast(Cart).makeText(Cart,msg,Toast.LENGTH_LONG).show();
                    Cart.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            acknowledge();
                        }
                    });
                }
            });
//            paymentMode.setVisibility(View.GONE);
//            checkout.setVisibility(View.VISIBLE);
//            pressToPlaceOrder.setVisibility(View.GONE);
//            paymentSelection.check(R.id.paytmMethod);
        }
        else {
            Intent intent = new Intent(CartActivity.Cart, PaytmTransactionActivity.class);
            intent.putExtra("txn_amount",total_amt.getText().toString().substring(2));
            intent.putExtra("orderObj",orderObj.toString());
            CartActivity.Cart.startActivityForResult(intent, PAYTMTRANSACTIONREQUESTCODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
        String PAYTM_CHECKSUM_NEW = "https://www.mealgaadi.in//paytm_App/generateChecksum_new.php";
        if(resultCode == RESULT_OK && requestCode == PAYTMTRANSACTIONREQUESTCODE){
            try {
                acknowledge();
                String jsondata = data.getStringExtra("jsondata");
                Log.e("onActivityResult", jsondata);

                JSONObject jsonObject = new JSONObject(jsondata);
                String datam = jsonObject.getJSONObject("mMap").toString();
                Log.e("mMap",datam);
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        else{

            new AlertDialog.Builder(Cart)
                    .setTitle("Oops!!!")
                    .setMessage("Your order has not been placed, please follow process carefully!!!")

                    // Specifying a listener allows you to take an action before dismissing the dialog.
                    // The dialog is automatically dismissed when a dialog button is clicked.
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            // Continue with delete operation
                        }
                    })

                    // A null listener allows the button to dismiss the dialog and take no further action.
                    .setIcon(R.drawable.nav_header_image).setCancelable(false).show();
        }
    }

    static void acknowledge(){
        new AlertDialog.Builder(Cart)
                .setTitle("Order Placed!")
                .setMessage("Your order has been placed.")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        // Continue with delete operation
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setIcon(R.drawable.nav_header_image).setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                CartActivity.Cart.startActivity(new Intent(Cart,MainActivity.class));
                CartActivity.Cart.finish();
            }
        }).setCancelable(false).show();
        dbw.execSQL("delete from "+ FeedReader.FeedEntry.TABLE_NAME);
        MainActivity.cartList.clear();
        adapterItem.notifyDataSetChanged();
    }

    void mypaytmcode(){

//            String appPackageName = "net.one97.paytm";
//            PackageManager pm = this.getPackageManager();
//            Intent appstart = pm.getLaunchIntentForPackage(appPackageName);
//            if(null!=appstart)
//            {
//                this.startActivity(appstart);
//            }
//            else {
//                Toast.makeText(this, "Install PayTm on your device", Toast.LENGTH_SHORT).show();
//            }

        if (ContextCompat.checkSelfPermission(Cart, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Cart, new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
        }

        final PaytmPGService Service = PaytmPGService.getStagingService();
//            'b0KvE!uTa0W5xjgG'?
//        'PAYTM_MERCHANT_MID', 'MealGa26731361105289'
//        'PAYTM_MERCHANT_WEBSITE', 'MealGaWEB'
        final HashMap<String, String> paramMap = new HashMap<String,String>();

//            paramMap.put( "MERCHANT_KEY" , "g8x#%F286@KtBG5A");
        paramMap.put( "MID" , "iKzvBt45457756179911");
//            paramMap.put("KEY","b0KvE!uTa0W5xjgG");
// Key in your staging and production MID available in your dashboard
        paramMap.put( "ORDER_ID" , orderId);
        paramMap.put( "CUST_ID" , new Session(Cart).getUserId());
        paramMap.put( "MOBILE_NO" , new Session(Cart).getUserNumber());
        paramMap.put( "EMAIL" , "kartik4797@gmail.com");
        paramMap.put( "CHANNEL_ID" , "WAP");
        paramMap.put( "TXN_AMOUNT" , CartActivity.total_amt.getText().toString().substring(2));
        paramMap.put( "WEBSITE" , "WEBSTAGGING");
//            PaytmMerchant Merchant = new PaytmMerchant("https://www.mealgaadi.in//paytm_App/generateChecksum.php","https://www.mealgaadi.in//paytm_App/verifyChecksum.php");
// This is the staging value. Production value is available in your dashboard
        paramMap.put( "INDUSTRY_TYPE_ID" , "Retail");
// This is the staging value. Production value is available in your dashboard
        paramMap.put( "CALLBACK_URL", "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID="+orderId);
//            paramMap.put("CALLBACK_URL","https://www.mealgaadi.in//paytm_App/verifyChecksum.php");
//            paramMap.put("CALLBACK_URL","https://securegw.paytm.in/theia/paytmCallback");
//            paramMap.put("CHANNEL_ID","WAP");
//            paramMap.put("CHECKSUMHASH","yDZks+XoWcQ4YZJ+Iod+f/b/7mi5tcGqqQELPhSLQYjGdUfcUnsegcjlsdW797gnsvy4YrHNV8HSIJmdFN0NgWbNTle8wgKFAnSH14crB3A=");
//            paramMap.put("CUST_ID","test111");
//            paramMap.put("INDUSTRY_TYPE_ID","Retail");
//            paramMap.put("MID","TECHOP10964184510936");
//            paramMap.put("ORDER_ID","1523342168787");
//            paramMap.put("TXN_AMOUNT","1");
//            paramMap.put("WEBSITE","TECHweb");
//            paramMap.put("CALLBACK_URL","https://www.mealgaadi.in//paytm_App/verifyChecksum.php"+checksum);
//            String paytmChecksum = CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey, paytmParams);
        paramMap.put( "CHECKSUMHASH" , checksum);
        OkHttpClient client=new OkHttpClient();
        JsonObject user=new JsonObject();

        user.addProperty( "PAYTM_MERCHANT_KEY" , "b0KvE!uTa0W5xjgG");
        user.addProperty("PAYTM_MERCHANT_MID","MealGa26731361105289");
// Key in your staging and production MID available in your dashboard
        user.addProperty( "ORDER_ID" , CartActivity.orderId);
        user.addProperty( "CHANNEL_ID" , "WAP");
        user.addProperty( "CUST_ID" , new Session(Cart).getUserId());
        user.addProperty( "MOBILE_NO" , new Session(Cart).getUserNumber());
        user.addProperty( "EMAIL" , "kartik4797@gmail.com");
        user.addProperty( "TXN_AMOUNT" , CartActivity.total_amt.getText().toString().substring(2));
        user.addProperty( "PAYTM_MERCHANT_WEBSITE" , "MealGaWEB");
// This is the staging value. Production value is available in your dashboard
        user.addProperty( "INDUSTRY_TYPE_ID" , "Retail");
//// This is the staging value. Production value is available in your dashboard
        user.addProperty( "CALLBACK_URL", "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID="+CartActivity.orderId);
//        user.addProperty("CALLBACK_URL","https://www.mealgaadi.in/");
        user.addProperty("CHECKSUMHASH",checksum);
//        user.addProperty("CALLBACK_URL","https://www.mealgaadi.in/");
        Log.e("verify reqobj", user.toString());


        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), user.toString());
        Request request = new Request.Builder()
                .url("https://www.mealgaadi.in//paytm_App/verifyChecksum.php")
                .post(body)
                .build();
//                try {
        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                Log.e("on failure : ", call.toString() + "exception " + e.getMessage());
                final String message = e.getMessage();
            }

            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                String verify = response.body().string();
                Log.e("this is verified : ", verify);
                if(verify.equals("Y")) {
                    PaytmOrder Order = new PaytmOrder(paramMap);
                    Service.initialize(Order, null);
                    Log.e("checksum", CartActivity.checksum);
//            Log.e("request",String.valueOf(Order));
                    Log.e("request", String.valueOf(paramMap));

                    Service.startPaymentTransaction(CartActivity.Cart, true, true, new PaytmPaymentTransactionCallback() {
                        /*Call Backs*/
//            public void someUIErrorOccurred(String inErrorMessage) {}
//            public void onTransactionResponse(Bundle inResponse) {}
//            public void networkNotAvailable() {}
//            public void clientAuthenticationFailed(String inErrorMessage) {}
//            public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {}
//            public void onBackPressedCancelTransaction() {}
                        public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                            Toast.makeText(Cart, "Transaction cancelled due to: " + inErrorMessage, Toast.LENGTH_LONG).show();
                            Log.e("paytm error: ", inErrorMessage);
                        }

                        public void onTransactionResponse(Bundle inResponse) {
                            /*Display the message as below */
                            Toast.makeText(Cart, "Payment Transaction response " + inResponse.toString(), Toast.LENGTH_LONG).show();
                            Log.e("paytm response : ", inResponse.toString());
                        }

                        public void someUIErrorOccurred(String inErrorMessage) {
                            /*Display the error message as below */
                            Toast.makeText(Cart, "UI Error " + inErrorMessage, Toast.LENGTH_LONG).show();
                            Log.e("paytm error: ", inErrorMessage);
                        }

                        public void networkNotAvailable() {
                            /*Display the message as below */
                            Toast.makeText(Cart, "Network connection error: Check your internet connectivity", Toast.LENGTH_LONG).show();
                        }

                        public void clientAuthenticationFailed(String inErrorMessage) {
                            /*Display the message as below */
                            Log.e("paytm error: ", inErrorMessage);
                            Toast.makeText(Cart, "Authentication failed: Server error" + inErrorMessage, Toast.LENGTH_LONG).show();
                        }

                        public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
                            /*Display the message as below */
                            Log.e("paytm error: ", inErrorMessage);
                            Toast.makeText(Cart, "Unable to load webpage " + inErrorMessage, Toast.LENGTH_LONG).show();
                        }

                        public void onBackPressedCancelTransaction() {
                            /*Display the message as below */
                            Toast.makeText(Cart, "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }

                    });
                }
                else {
                    orderId=String.valueOf(Math.abs(new Random().nextLong()));
                    new CallChecksum(Cart).execute();
                }
            }
        });
    }
        @Override
    public void onBackPressed() {
//            MainActivity.backFromCart=true;
            Intent intent=new Intent(CartActivity.this,MainActivity.class);
            intent.putExtra("backFromCart",true);
        startActivity(intent);
            CartActivity.this.finish();
        }

    @Override
    protected void onDestroy() {
        dbc.close();
        super.onDestroy();
    }
}

