package com.e.beercrafthackathon;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.mealgaadi.Coupan;
import com.mealgaadi.Session;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.graphics.Color.BLACK;
import static android.graphics.Color.GRAY;
import static com.mealgaadi.R.id.search_here;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    public static TextView cart_top;
    public static ArrayList<Item> cartList;
    public static RecyclerView recyclerView;
    public static AutoCompleteTextView searchIt;
    public static ArrayList<Item> list;
    public static ArrayList<Coupan> coupanlist;
    public static boolean backFromCart;
    DatabaseCreation dbc;
    LinearLayout inflatorViewGroup;
    SQLiteDatabase dbw,dbr;
    ContentValues cv;
    Cursor cursor;
    LayoutInflater layoutInflater;
    static ItemAdapter mainAdapter;
    static ViewGroup layoutView;
    NavigationView navigationView;
    static FragmentManager fragmentManager;
    Session session;
    public static MainActivity mainActivity;
    private final static String API_KEY="product_menus_all";
    static Location myLocation;
    static String myAddress;
    static int cartCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Intent welcome=new Intent(this,SplashScreenActivity.class);
//        startActivity(welcome);

//        setContentView(R.layout.start_splash_screen);

//        ImageView splash = (ImageView) findViewById(R.id.splash_screen);
//        GlideDrawableImageViewTarget imageViewTarget = new GlideDrawableImageViewTarget(splash);
//        Glide.with(this).load(R.drawable.splash_background).into(imageViewTarget);
//
//        findViewById(R.id.main_layout).setVisibility(View.VISIBLE);
//        findViewById(R.id.splash_screen).setVisibility(View.GONE);
        session=new Session(getApplicationContext());
        session.checkLogin();
        setContentView(R.layout.activity_navigation_bar);
        mainActivity=MainActivity.this;
        dbc=new DatabaseCreation(getApplicationContext());
        dbw=dbc.getWritableDatabase();
        dbr=dbc.getReadableDatabase();
        cv=new ContentValues();
        cartCount=0;
        try {
            cursor = dbr.rawQuery("select * from " + FeedReader.FeedEntry.TABLE_NAME, null);

            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {
                    cartCount++;
//                    objlist.add(new MyObj(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.STATUS)), cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.DETAIL)),
//                            cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.DATE_ASSIGNED)), cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.ASSIGNED_TO))));
                    cursor.moveToNext();
                }
            }
        }catch (SQLiteException e){}

        //display the logo during 5 seconds,
//        new CountDownTimer(5000,1000){
//
//            @Override
//            public void onTick(long millisUntilFinished){}
//
//            @Override
//            public void onFinish(){
//                //set the new Content of your activity
//
//            }
//        }.start();

            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();

            navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);
            navigationView.setItemHorizontalPadding(32);
            SpannableString spannableString;
            for (int i = 0; i < 22; i++) {
                MenuItem item = navigationView.getMenu().getItem(i);
                spannableString = new SpannableString(item.getTitle());
                if ((i > 3) && (i < 17)) {
                    spannableString.setSpan(new ForegroundColorSpan(GRAY), 0, spannableString.length(), 0);
                } else
                    spannableString.setSpan(new ForegroundColorSpan(BLACK), 0, spannableString.length(), 0);
                item.setTitle(spannableString);
            }
            navigationView.removeHeaderView(navigationView.getHeaderView(0));
            View headerView = navigationView.inflateHeaderView(R.layout.nav_header_navigation_bar);
            headerView.findViewById(R.id.fb_icon).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = "https://www.facebook.com/mealgaadi";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });
            FloatingActionButton fab=findViewById(R.id.fab);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this,ChatBotActivity.class));
                }
            });
            headerView.findViewById(R.id.twitter_icon).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = "https://twitter.com/MealGaadiIndore";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });
            headerView.findViewById(R.id.youtube_icon).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = "https://www.youtube.com/channel/UCEBhzJ4bjExb3gRrQZGGP_Q";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });
            headerView.findViewById(R.id.insta_icon).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = "https://www.instagram.com/mealgaadiindore/";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });
            //new DownloadImageTask().setImage((ImageView)headerView.findViewById(R.id.imageView),"https://is2-ssl.mzstatic.com/image/thumb/Purple125/v4/50/20/33/502033f8-8c22-eee4-4fc4-45f331f2f728/mzl.vjtihlhf.jpg/1200x630wa.jpg",(ProgressBar)headerView.findViewById(R.id.progress_bar_nav_header),true);
            /**/

            coupanlist = new ArrayList<>();


            coupanlist.add(new Coupan("First Order Offer",
                    "Get 100% Cashback On Your First Order",
                    "FIRST100", "Limited Period Offer", "http://www.mealgaadi.in/administrator/images/couponsOffer/5cb2174f34a88.png"));
            coupanlist.add(new Coupan("Mealgaadi - Happy Hours",
                    "Get 20% Off On All Orders Above Rs. 150/-", "USE CODE - MGD-HAPPYHOUR",
                    "ORDER BETWEEN 6:00 PM - 09:00 PM", "http://www.mealgaadi.in/administrator/images/couponsOffer/5c88e5597843a.png"
            ));
            coupanlist.add(new Coupan("Mealgaadi - 50% Cashback",
                    "Get 50% Cashback On First Order Paid Via PayPal",
                    "Place Your Order & Pay Via PayPal",
                    "ORDER BETWEEN 12:00PM - 04:00AM", "http://www.mealgaadi.in/administrator/images/couponsOffer/5c792542e62c9.png"
            ));
            coupanlist.add(new Coupan("We At Mealgaadi Value Your Feedback",
                    "Mealgaadi Requests All Our Customers To Spare Some Time And Provide Us Their Valuable Feedback. Just Fill Form & Get 20% Off On Next Order.",
                    "Http://bit.ly/2IKeVK7", "Use This Link -"
                    , "http://www.mealgaadi.in/administrator/images/couponsOffer/5ab4de03b0bba.png"
            ));
            coupanlist.add(new Coupan("Mealgaadi - Referral Hours",
                    "Refer Us To Your Friend Near And Dear Once And Get 20% Cashback On Their First Order.",
                    "-",
                    "ORDER BETWEEN 12:00PM - 04:00AM", "http://www.mealgaadi.in/administrator/images/couponsOffer/5c7925adbbd71.png"
            ));
            cart_top = (TextView) findViewById(R.id.cart_count);
//            if (cart_top.getText().toString().equals(""))
                cart_top.setText(String.valueOf(cartCount));

        ItemApiInterface apiService =
                ItemApiClient.getClient().create(ItemApiInterface.class);
        list=new ArrayList<Item>();

        Call<ItemResponse> call = apiService.getMenuItems();
        call.enqueue(new Callback<ItemResponse>() {
            @Override
            public void onResponse(Call<ItemResponse>call, Response<ItemResponse> response) {
                for (int i=0;i<response.body().getResults().size();i++)
                    list.add(response.body().getResults().get(i));

                if (list!=null)
                    ProductListFragment.adapter.setList(list);
//                new Toast(MainActivity.this).makeText(MainActivity.this,"status code: "+response.body().getStatus()+"",Toast.LENGTH_LONG).show();
//                list = new ArrayList<>(response.body().getResults());
                if (list==null)
                    new Toast(MainActivity.this).makeText(MainActivity.this,"list is null",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<ItemResponse>call, Throwable t) {
                // Log error here since request failed
                Log.e(MainActivity.class.getSimpleName(), t.toString());
                new Toast(MainActivity.this).makeText(MainActivity.this,"failed to fetch data from api!!! due to "+t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });


//            String[] item1 = {"Main Course Paneer", "Main Course Veg"};
//            String[] item2 = {"Maggi", "Snacks"};
//            String[] item3 = {"Snacks"};
//            list.add(new Item("chilli paneer", 232, 343, item1));
//            list.add(new Item("crispy chana masala", 121, 212, item3));
//            list.add(new Item("kalali pakode", 212, 323, item3));
//            list.add(new Item("paneer tadka maggi", 1111, 1211, item2));
//            list.add(new Item("mix veg maggi", 21, 23, item2));
//            list.add(new Item("tadka maggi", 544, 567, item2));

   /*     ImageView menuIcon=(ImageView)findViewById(R.id.menu_ico);
        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),NavigationBar.class);
                startActivity(intent);
            }
        });
*/
//

//            int layoutInflatorOn = 0;
            layoutInflater = LayoutInflater.from(this);
            inflatorViewGroup = (LinearLayout) findViewById(search_here);

            cartList = new ArrayList<>();
            final Intent intentCart = new Intent(this, CartActivity.class);
            View.OnClickListener onClickListener = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(intentCart);
                    finish();
                }
            };
            cart_top.setOnClickListener(onClickListener);
            ImageView cart = (ImageView) findViewById(R.id.cart_top_icon);
            cart.setOnClickListener(onClickListener);

            getAddress();

            final RelativeLayout search = (RelativeLayout) findViewById(R.id.search_icon);
            search.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    changeFragmentToProductList();
                    if (layoutView != null) {
                        if (layoutView.getVisibility() == View.VISIBLE) {
                            searchIt.setText("", true);
                            layoutView.setVisibility(View.GONE);
                            layoutView=null;
                            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                            if(getCurrentFocus()!=null && getCurrentFocus().getWindowToken()!=null)
                            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                            CoordinatorLayout.LayoutParams layoutParams1=new CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                            layoutParams1.setMargins(0,0,16*(getApplicationContext().getResources().getDisplayMetrics().densityDpi/ DisplayMetrics.DENSITY_DEFAULT),70*(getApplicationContext().getResources().getDisplayMetrics().densityDpi/ DisplayMetrics.DENSITY_DEFAULT));
                            layoutParams1.gravity= Gravity.BOTTOM|Gravity.END;
                            fab.setLayoutParams(layoutParams1);
                            }
//                        } else if (layoutView.getVisibility() == View.GONE) {
//                            layoutView.setVisibility(View.VISIBLE);
//                            searchIt.setText("", true);
//                        }
                    } else {
                        layoutView = (ViewGroup) layoutInflater.inflate(R.layout.search_view, inflatorViewGroup, true);
                        layoutView.setVisibility(View.VISIBLE);
                        searchIt = (AutoCompleteTextView) findViewById(R.id.search_text);
                        searchIt.setThreshold(1);
                        searchIt.addTextChangedListener(new CustomTextChangedListener(MainActivity.this));
                        searchIt.setTextColor(getResources().getColor(R.color.colorPrimary));
                        searchIt.setText("", true);
                        CoordinatorLayout.LayoutParams layoutParams=new CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                        layoutParams.setMargins(0,0,16*(getApplicationContext().getResources().getDisplayMetrics().densityDpi/ DisplayMetrics.DENSITY_DEFAULT),120*(getApplicationContext().getResources().getDisplayMetrics().densityDpi/ DisplayMetrics.DENSITY_DEFAULT));
                        layoutParams.gravity= Gravity.BOTTOM|Gravity.END;
                        fab.setLayoutParams(layoutParams);
                    }

                }
                    /*
                String[] searchList=new String[list.size()];

                for(int i=0;i<list.size();i++) {
                    searchList[i]=list.get(i).getName();
                }

                ArrayAdapter<String> tempAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,searchList);
*/
            });

       /* dbc=new DatabaseCreation(getApplicationContext());
        dbw=dbc.getWritableDatabase();
        dbr=dbc.getReadableDatabase();
        cv=new ContentValues();
        try {
            cursor = dbr.rawQuery("select * from " + FeedReader.FeedEntry.TABLE_NAME, null);

            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {
                    cartList.add(new Item(cursor.getString(cursor.getColumnIndex(FeedReader.FeedEntry.NAME)),
                            cursor.getInt(cursor.getColumnIndex(FeedReader.FeedEntry.NEW_PRICE)), cursor.getInt(cursor.getColumnIndex(FeedReader.FeedEntry.OLD_PRICE))));
                    cursor.moveToNext();
                }
            }
        }catch (SQLiteException e){}
        adapter = new ItemAdapter(list);
        recyclerView.setAdapter(adapter);
*/

            final Intent intentGift = new Intent(this, GiftActivity.class);
            TextView giftCount = findViewById(R.id.gift_count);
            ImageView giftIcon = findViewById(R.id.gift_icon);
            if (coupanlist != null)
                giftCount.setText(String.valueOf(coupanlist.size()));
            else giftCount.setText(0);
            giftIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (layoutView != null){
                        layoutView.setVisibility(View.GONE);
                        layoutView=null;
                        CoordinatorLayout.LayoutParams layoutParams1=new CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                        layoutParams1.setMargins(0,0,16*(getApplicationContext().getResources().getDisplayMetrics().densityDpi/ DisplayMetrics.DENSITY_DEFAULT),70*(getApplicationContext().getResources().getDisplayMetrics().densityDpi/ DisplayMetrics.DENSITY_DEFAULT));
                        layoutParams1.gravity= Gravity.BOTTOM|Gravity.END;
                        fab.setLayoutParams(layoutParams1);
                    }
                    changeFragmentToGiftList();
                }
            });

            mainAdapter = new ItemAdapter(list);

            fragmentManager = getSupportFragmentManager();
            addHomeFragment();
            changeFragmentToProductList();
            changeFragmentToHome();
            backFromCart=false;
        if(getIntent()!=null && getIntent().getBooleanExtra("backFromCart",false))
            backFromCart=getIntent().getBooleanExtra("backFromCart",false);
            if (backFromCart){
                changeFragmentToProductList();
//                search.performClick();
//                search.performClick();
            }
        backFromCart=false;
        }

        public static void getAddress(){
            FusedLocationProviderClient fusedLocationClient;

            fusedLocationClient = LocationServices.getFusedLocationProviderClient(MainActivity.mainActivity);
            if (ActivityCompat.checkSelfPermission(MainActivity.mainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.mainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                ActivityCompat.requestPermissions(MainActivity.mainActivity,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},1);
                // here to request the missing permissions, and then overriding
//               public void onRequestPermissionsResult(int requestCode, ACCES,
//                                                      int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                Log.e("permission :","take permission");
                fusedLocationClient.getLastLocation()
                        .addOnSuccessListener(MainActivity.mainActivity, new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                // Got last known location. In some rare situations this can be null.
                                if (location != null) {
                                    Log.e("location: ",location.toString());
                                    myLocation=location;
                                    getAddressFromLocation(location);
                                }
                            }
                        })
                        .addOnFailureListener(MainActivity.mainActivity, new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("failed location: ",e.getMessage());
                            }
                        });

            }
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(MainActivity.mainActivity, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                Log.e("lastlocation: ",location.toString());
                                myLocation=location;
                                getAddressFromLocation(location);
                            }
                        }
                    })
                    .addOnFailureListener(MainActivity.mainActivity, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("failed location: ",e.getMessage());
                        }
                    });

            LocationRequest locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.
                    PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(20 * 1000);
            LocationCallback locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    if (locationResult == null) {
                        return;
                    }
                    for (Location location : locationResult.getLocations()) {
                        if (location != null) {
                            myLocation=location;
                            getAddressFromLocation(location);
                            Log.e("current loc :",myLocation.toString());
                            return;
                        }
                    }
                }
            };
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }

    @Override
    protected void onDestroy() {
        dbc.close();
        super.onDestroy();
    }

    static void getAddressFromLocation(Location location){

            if (location != null) {
                Log.e("addresslocation: ", location.toString());
                double Lat = location.getLatitude();
                double Lon = location.getLongitude();
                Log.e("Address", "Lat");
                double latitude = Lat;
                double longitude = Lon;
                Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(MainActivity.mainActivity, Locale.getDefault());
                try {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                    myAddress = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                    String city = addresses.get(0).getLocality();
                    String state = addresses.get(0).getAdminArea();
                    String country = addresses.get(0).getCountryName();
                    String postalCode = addresses.get(0).getPostalCode();
                    String knownName = addresses.get(0).getFeatureName();
//                Toast.makeText(context, address + ".", Toast.LENGTH_SHORT).show();
                    Log.e("Address", myAddress + ".");
                    Session session=new Session(MainActivity.mainActivity);
                    session.setAddress(myAddress);
                    session.setLatitude(latitude);
                    session.setLongitude(longitude);
                    session.setLocation(myLocation);
                    session.setCity(city);
                } catch (Exception e) {
//                Toast.makeText(context, "Address ", Toast.LENGTH_SHORT).show();
                    Log.e("Address", "catch");
                }
            }
        }

    public static void addHomeFragment(){
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        MainHomeFragment fragment = new MainHomeFragment();
        fragmentTransaction.add(R.id.main_fragment, fragment);
        fragmentTransaction.commit();
    }

    public static void changeFragmentToHome(){
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        MainHomeFragment fragment = new MainHomeFragment();
        fragmentTransaction.replace(R.id.main_fragment, fragment);
        fragmentTransaction.commit();
    }

    public static void changeFragmentToProductList(){
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        ProductListFragment fragment=new ProductListFragment();
        fragmentTransaction.replace(R.id.main_fragment,fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public static void changeFragmentToGiftList(){
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        GiftMainFragment fragment=new GiftMainFragment();
        fragmentTransaction.replace(R.id.main_fragment,fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (layoutView!=null && layoutView.getVisibility()==View.VISIBLE) {
            layoutView.setVisibility(View.GONE);
        }
            else{
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    public static void filterResults(String text){
        if(layoutView!=null && layoutView.getVisibility()==View.VISIBLE)
            layoutView.setVisibility(View.GONE);
        ProductListFragment.filter(text);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.home_activity_start) {
            startActivity(new Intent(this,MainActivity.class));
            this.finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.menu_filter) {
            for(int i=4;i<17;i++) {
                    navigationView.getMenu().getItem(i).setVisible(!navigationView.getMenu().getItem(i).isVisible());
            }
        }
        switch (id){
            case R.id.nav_order_history:
                drawer.closeDrawer(GravityCompat.START);
                Intent orderhistoryintent=new Intent(this,OrderHistoryActivity.class);
                startActivity(orderhistoryintent);
                this.finish();
                break;
            case R.id.nav_profile:
                drawer.closeDrawer(GravityCompat.START);
                Intent userprofileintent=new Intent(this,UserProfile.class);
                startActivity(userprofileintent);
                this.finish();
                break;
            case R.id.nav_logout:
                drawer.closeDrawer(GravityCompat.START);
                session.logoutUser();
                finish();
                break;
            case R.id.nav_refer:
                drawer.closeDrawer(GravityCompat.START);
                Intent intent=new Intent(this,ReferActivity.class);
                startActivity(intent);
                break;
            case R.id.nav_home:
                drawer.closeDrawer(GravityCompat.START);
                Intent intentHome=new Intent(this,MainActivity.class);
                startActivity(intentHome);
                this.finish();
                break;
            case R.id.nav_terms_and_conditions:
                drawer.closeDrawer(GravityCompat.START);
                Intent intentTerms=new Intent(this,TermsConditions.class);
                startActivity(intentTerms);
                break;
            case R.id.nav_contact_us:
                drawer.closeDrawer(GravityCompat.START);
                Intent intentContactUs=new Intent(this,ContactUs.class);
                startActivity(intentContactUs);
                break;
            case R.id.nav_about_us:
                drawer.closeDrawer(GravityCompat.START);
                Intent intentAboutUs=new Intent(this,AboutUs.class);
                startActivity(intentAboutUs);
                break;
            case R.id.snacks:
                filterResults("22");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.maggi:
                filterResults("23");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.rolls:
                filterResults("rol");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.main_course_paneer:
                filterResults("27");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.main_course_veg:
                filterResults("26");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.dal:
                filterResults("28");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.rice:
                filterResults("29");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.roti:
                filterResults("39");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.combo_specials:
                filterResults("33");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.combo_rice:
                filterResults("34");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.combo_roti:
                filterResults("35");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.group_meal:
                filterResults("40");
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.addons:
                filterResults("31");
                drawer.closeDrawer(GravityCompat.START);
                break;
        }

        /*DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);*/
        return true;
    }
/**/

}
