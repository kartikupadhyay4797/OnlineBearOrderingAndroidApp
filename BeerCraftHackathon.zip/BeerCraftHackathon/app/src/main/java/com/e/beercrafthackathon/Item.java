package com.e.beercrafthackathon;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Item implements Serializable {
    private String type;
    @SerializedName("menu_Id")
    private String menu_Id;
    @SerializedName("category_Id")
    private String category_Id;
    @SerializedName("name")
    private String name;
    @SerializedName("hindi")
    private String hindi;
    @SerializedName("img")
    private String url;
    @SerializedName("price_Option")
    private String price_Option;
    @SerializedName("single_Price")
    private String single_Price;
    @SerializedName("Half")
    private String half;
    @SerializedName("Full")
    private String full;
    @SerializedName("imagess")
    private String[] imagess;
    private String priceForCart;
//    @SerializedName("multi_Price")
//    private ArrayList<String> multi_Price;
    private int quantity=0;

    public String[] getImagess() {
        return imagess;
    }

    public void setImagess(String[] imagess) {
        this.imagess = imagess;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPriceForCart() {
        return priceForCart;
    }

    public void setPriceForCart(String priceForCart) {
        this.priceForCart = priceForCart;
    }

    public String getHalf() {
        return half;
    }

    public void setHalf(String half) {
        this.half = half;
    }

    public String getFull() {
        return full;
    }

    public void setFull(String full) {
        this.full = full;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Item() {
    }

    public String getMenu_Id() {
        return menu_Id;
    }

    public void setMenu_Id(String menu_Id) {
        this.menu_Id = menu_Id;
    }

    public String getCategory_Id() {
        return category_Id;
    }

    public void setCategory_Id(String category_Id) {
        this.category_Id = category_Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHindi() {
        return hindi;
    }

    public void setHindi(String hindi) {
        this.hindi = hindi;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPrice_Option() {
        return price_Option;
    }

    public void setPrice_Option(String price_Option) {
        this.price_Option = price_Option;
    }

    public String getSingle_Price() {
        return single_Price;
    }

    public void setSingle_Price(String single_Price) {
        this.single_Price = single_Price;
    }

}
