package com.e.beercrafthackathon;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ItemApiInterface {
    @GET("products_api.php?query=product_menus_all")
    Call<ItemResponse> getMenuItems();

    @POST("customer_api.php")
    Call<UserResponse> loginRequest(@Body LoginDetails loginDetails);

    @POST("customer_api.php")
    Call<UserResponseError> loginError(@Body LoginDetails loginDetails);

    @POST("customer_api.php")
    Call<okhttp3.ResponseBody> signUpRequest(@Body User user);

    @POST("customer_api.php")
    Call<UserResponseError> signUpError(@Body User user);


//    @GET("movie/{id}")
//    Call<ItemResponse> getMovieDetails(@Path("id") int id, @Query("api_key") String apiKey);
}
