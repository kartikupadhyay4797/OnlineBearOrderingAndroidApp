package com.e.beercrafthackathon;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ItemResponse {
        @SerializedName("status")
        private String status;
        @SerializedName("result")
        private ArrayList<Item> results;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<Item> getResults() {
        return results;
    }

    public void setResults(ArrayList<Item> results) {
        this.results = results;
    }
}
